 sed -i.bak -e "s#view/otih-oith/##g"  home.html 
