Parse.Cloud.define('cloudCodeInFile', (req, res) => {
  res.success('It is possible to define cloud code in a file.');
});
